# Cocos Creator 贝塞尔曲线编辑器

效果如下：

![贝塞尔](bezier.gif)

- 使用cocos creator实现贝塞尔曲线编辑，目前是一个比较简单的demo。

- 匀速贝塞尔曲线还在制作之中，马上就可以搞完了。

##### 详细的技术讲解请关注我的微信公号：

<div align=center>
<img src="https://img-blog.csdnimg.cn/20190605101043274.png"  />
</div>
